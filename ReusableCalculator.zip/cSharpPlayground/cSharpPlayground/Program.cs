﻿using System;

namespace cSharpPlayground
{
    class Program
    {
        static void Main(string[] args)
        {
            

            

            string answer = "Yes";

            while (answer != "No")
            {
                Console.WriteLine("Please enter the first number");

                int number1 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the second number");

                int number2 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Select an operator by number:");
                Console.WriteLine("1 for addition");
                Console.WriteLine("2 for subtraction");
                Console.WriteLine("3 for multiplication");
                Console.WriteLine("4 for division");

                string @operator = Console.ReadLine();

                switch (@operator)
                {
                    case "1":
                        Console.WriteLine(number1 + number2 + "\n");
                    break;
                    case "2":
                        Console.WriteLine(number1 - number2 + "\n");
                    break;
                    case "3":
                        Console.WriteLine(number1 * number2 + "\n");
                    break;
                    case "4":
                        Console.WriteLine(number1 / number2 + "\n");
                    break;
                    default:
                        Console.WriteLine("Please enter an actual operator\n");
                    break;

                }
                Console.WriteLine("Would you like to reset the calculator? Type in 'Yes' or 'No'");
                answer = Console.ReadLine();
                Console.WriteLine("\n");
            }
            Console.WriteLine("Thanks for using the calculator! Exiting program now.");
        }
    }
}
